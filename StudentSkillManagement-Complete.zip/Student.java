import java.util.ArrayList;
import java.util.List;

public class Student {

    // 1. Private attributes (Encapsulation)
    private int studentId;
    private String studentName;
    private String email;
    private String courseName;
    private double programmingScore;
    private double mathematicsScore;
    private List<String> technicalSkills;

    // 2. Constructor
    public Student(int studentId, String studentName,
                   String email, String courseName,
                   double programmingScore,
                   double mathematicsScore,
                   List<String> technicalSkills) {

        this.studentId = studentId;
        this.studentName = studentName;
        this.email = email;
        this.courseName = courseName;
        this.programmingScore = programmingScore;
        this.mathematicsScore = mathematicsScore;
        this.technicalSkills = new ArrayList<>(technicalSkills);
    }

    // 3. Getters
    public int getStudentId() {
        return studentId;
    }

    public String getStudentName() {
        return studentName;
    }

    public String getEmail() {
        return email;
    }

    public String getCourseName() {
        return courseName;
    }

    public double getProgrammingScore() {
        return programmingScore;
    }

    public double getMathematicsScore() {
        return mathematicsScore;
    }

    public List<String> getTechnicalSkills() {
        return new ArrayList<>(technicalSkills);
    }

    // 4. Setters
    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public void setProgrammingScore(double score) {
        if (score >= 0 && score <= 100) {
            this.programmingScore = score;
        }
    }

    public void setMathematicsScore(double score) {
        if (score >= 0 && score <= 100) {
            this.mathematicsScore = score;
        }
    }

    public void setTechnicalSkills(List<String> skills) {
        this.technicalSkills = new ArrayList<>(skills);
    }

    // 5. Object/business methods
    public double calculateAverage() {
        return (programmingScore + mathematicsScore) / 2;
    }

    public String getStrongerSubject() {
        if (programmingScore > mathematicsScore) {
            return "Programming";
        } else if (mathematicsScore > programmingScore) {
            return "Mathematics";
        } else {
            return "Both are equal";
        }
    }

    public String getPerformanceCategory() {
        double avg = calculateAverage();

        if (avg >= 85) return "Excellent";
        else if (avg >= 70) return "Good";
        else if (avg >= 50) return "Satisfactory";
        else return "Needs Improvement";
    }

    public void displayDetails() {
        System.out.println("Student ID: " + studentId);
        System.out.println("Name: " + studentName);
        System.out.println("Email: " + email);
        System.out.println("Course: " + courseName);
        System.out.println("Programming: " + programmingScore);
        System.out.println("Mathematics: " + mathematicsScore);
        System.out.println("Skills: " + technicalSkills);
        System.out.println("Average: " + calculateAverage());
        System.out.println("Stronger Subject: " + getStrongerSubject());
        System.out.println("Category: " + getPerformanceCategory());
    }
}
