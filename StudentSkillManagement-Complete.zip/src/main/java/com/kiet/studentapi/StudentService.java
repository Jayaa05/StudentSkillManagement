package com.kiet.studentapi;

import org.springframework.stereotype.Service;
import java.util.*;

@Service
public class StudentService {

    private final StudentRepository repository;

    public StudentService(StudentRepository repository) {
        this.repository = repository;
    }

    public Student addStudent(Student student) {
        if (student.getProgrammingScore() < 0 ||
            student.getProgrammingScore() > 100 ||
            student.getMathematicsScore() < 0 ||
            student.getMathematicsScore() > 100) {
            throw new IllegalArgumentException("Scores must be between 0 and 100");
        }

        return repository.save(student);
    }

    public List<Student> getAllStudents() {
        return repository.findAll();
    }

    public Student getStudentById(int id) {
        return repository.findById(id)
            .orElseThrow(() -> new RuntimeException("Student not found"));
    }

    public Student updateStudent(int id, Student updated) {
        Student student = getStudentById(id);

        student.setStudentName(updated.getStudentName());
        student.setEmail(updated.getEmail());
        student.setCourseName(updated.getCourseName());
        student.setProgrammingScore(updated.getProgrammingScore());
        student.setMathematicsScore(updated.getMathematicsScore());

        return repository.save(student);
    }

    public void deleteStudent(int id) {
        repository.deleteById(id);
    }

    public List<Student> getMeritList() {
        List<Student> students = repository.findAll();

        students.sort((a, b) ->
            Double.compare(b.getAverage(), a.getAverage()));

        return students;
    }
}
