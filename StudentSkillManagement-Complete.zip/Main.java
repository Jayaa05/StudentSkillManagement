import java.util.Arrays;

public class Main {
    public static void main(String[] args) {

        Student s1 = new Student(
            101,
            "Rahul",
            "rahul@gmail.com",
            "B.Tech IT",
            90,
            80,
            Arrays.asList("Java", "Python", "SQL")
        );

        s1.displayDetails();
    }
}
