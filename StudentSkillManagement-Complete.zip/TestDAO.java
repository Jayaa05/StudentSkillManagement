public class TestDAO {
    public static void main(String[] args) throws Exception {
        StudentDAO dao = new StudentDAO();

        System.out.println("\n--- ALL STUDENTS ---");
        dao.displayStudents();

        System.out.println("\n--- SEARCH BY ID ---");
        dao.searchById(101);

        System.out.println("\n--- SEARCH BY EMAIL ---");
        dao.searchByEmail("priya@gmail.com");

        System.out.println("\n--- SEARCH BY COURSE ---");
        dao.searchByCourse("B.Tech IT");

        System.out.println("\n--- MERIT LIST ---");
        dao.generateMeritList();

        System.out.println("\n--- PERFORMANCE ---");
        dao.showPerformance();

        System.out.println("\n--- STRONGER SUBJECT ---");
        dao.showStrongerSubject();

        System.out.println("\n--- COMMON SKILLS ---");
        dao.findCommonSkills();

        System.out.println("\n--- IMPROVEMENT STUDENTS ---");
        dao.findImprovementStudents();
    }
}
