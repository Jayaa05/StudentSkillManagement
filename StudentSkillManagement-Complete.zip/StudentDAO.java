import java.sql.*;

public class StudentDAO {

    public void displayStudents() throws SQLException {
        String sql = "SELECT * FROM students";

        try (Connection con = DBConnection.getConnection();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                System.out.println(rs.getInt("student_id") + " | " +
                    rs.getString("student_name") + " | " +
                    rs.getString("email") + " | " +
                    rs.getString("course_name"));
            }
        }
    }

    public void searchById(int id) throws SQLException {
        String sql = "SELECT * FROM students WHERE student_id = ?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next())
                    System.out.println("Student: " + rs.getString("student_name"));
                else
                    System.out.println("Student not found");
            }
        }
    }

    public void searchByEmail(String email) throws SQLException {
        String sql = "SELECT * FROM students WHERE email = ?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, email);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next())
                    System.out.println(rs.getString("student_name"));
            }
        }
    }

    public void searchByCourse(String course) throws SQLException {
        String sql = "SELECT * FROM students WHERE course_name = ?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, course);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next())
                    System.out.println(rs.getString("student_name"));
            }
        }
    }

    public void generateMeritList() throws SQLException {
        String sql = "SELECT student_name, " +
            "(programming_score + mathematics_score)/2 AS average " +
            "FROM students ORDER BY average DESC";

        try (Connection con = DBConnection.getConnection();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next())
                System.out.println(rs.getString("student_name") +
                    " : " + rs.getDouble("average"));
        }
    }

    public void showPerformance() throws SQLException {
        String sql = "SELECT student_name, " +
            "(programming_score + mathematics_score)/2 AS avg FROM students";

        try (Connection con = DBConnection.getConnection();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                double avg = rs.getDouble("avg");
                String category;

                if (avg >= 85) category = "Excellent";
                else if (avg >= 70) category = "Good";
                else if (avg >= 50) category = "Satisfactory";
                else category = "Needs Improvement";

                System.out.println(rs.getString("student_name") + " : " + category);
            }
        }
    }

    public void showStrongerSubject() throws SQLException {
        String sql = "SELECT student_name, programming_score, mathematics_score FROM students";

        try (Connection con = DBConnection.getConnection();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                double p = rs.getDouble("programming_score");
                double m = rs.getDouble("mathematics_score");

                String stronger = p > m ? "Programming" :
                    m > p ? "Mathematics" : "Equal";

                System.out.println(rs.getString("student_name") + " : " + stronger);
            }
        }
    }

    public void findCommonSkills() throws SQLException {
        String sql = "SELECT skill, COUNT(DISTINCT student_id) AS total " +
            "FROM student_skills GROUP BY skill " +
            "HAVING COUNT(DISTINCT student_id) > 1";

        try (Connection con = DBConnection.getConnection();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next())
                System.out.println(rs.getString("skill") + " : " +
                    rs.getInt("total") + " students");
        }
    }

    public void findImprovementStudents() throws SQLException {
        String sql = "SELECT student_name FROM students " +
            "WHERE programming_score < 50 AND mathematics_score >= 75";

        try (Connection con = DBConnection.getConnection();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next())
                System.out.println(rs.getString("student_name"));
        }
    }
}
